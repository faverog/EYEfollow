import time
from typing import Optional

from open_gaze.impl import _EyeTracker


class EyeTracker:
	def __init__(self, host="127.0.0.1", port=4242):
		self._tracker = _EyeTracker(host, port)
	
	def read_msg_async(self) -> Optional[tuple[str, dict[str, str]]]:
		return self._tracker.read_msg()

	def read_msg(self) -> tuple[str, dict[str, str]]:
		while (msg := self.read_msg_async()) is None:
			time.sleep(0.01)
		return msg

	@property
	def send_data(self) -> bool: return self._tracker.get_enable_send_data()
	@send_data.setter
	def send_data(self, val: bool):     self._tracker.set_enable_send_data(val)

	@property
	def send_counter(self) -> bool: return self._tracker.get_enable_send_counter()
	@send_counter.setter
	def send_counter(self, val: bool):     self._tracker.set_enable_send_counter(val)
	
	@property
	def send_time(self) -> bool: return self._tracker.get_enable_send_time()
	@send_time.setter
	def send_time(self, val: bool):     self._tracker.set_enable_send_time(val)

	@property
	def send_time_tick(self) -> bool: return self._tracker.get_enable_send_time_tick()
	@send_time_tick.setter
	def send_time_tick(self, val: bool):     self._tracker.set_enable_send_time_tick(val)
	
	@property
	def send_pog_fix(self) -> bool: return self._tracker.get_enable_send_pog_fix()
	@send_pog_fix.setter
	def send_pog_fix(self, val: bool):     self._tracker.set_enable_send_pog_fix(val)
	
	@property
	def send_pog_left(self) -> bool: return self._tracker.get_enable_send_pog_left()
	@send_pog_left.setter
	def send_pog_left(self, val: bool):     self._tracker.set_enable_send_pog_left(val)
	
	@property
	def send_pog_right(self) -> bool: return self._tracker.get_enable_send_pog_right()
	@send_pog_right.setter
	def send_pog_right(self, val: bool):     self._tracker.set_enable_send_pog_right(val)

	@property
	def send_pupil_left(self) -> bool: return self._tracker.get_enable_send_pupil_left()
	@send_pupil_left.setter
	def send_pupil_left(self, val: bool):     self._tracker.set_enable_send_pupil_left(val)
	
	@property
	def send_pupil_right(self) -> bool: return self._tracker.get_enable_send_pupil_right()
	@send_pupil_right.setter
	def send_pupil_right(self, val: bool):     self._tracker.set_enable_send_pupil_right(val)
	
	@property
	def send_cursor(self) -> bool: return self._tracker.get_enable_send_cursor()
	@send_cursor.setter
	def send_cursor(self, val: bool):     self._tracker.set_enable_send_cursor(val)
	
	@property
	def send_user_data(self) -> bool: return self._tracker.get_enable_send_user_data()
	@send_user_data.setter
	def send_user_data(self, val: bool):     self._tracker.set_enable_send_user_data(val)

	@property
	def show_calibration(self) -> bool: return self._tracker.get_calibrate_show()
	@show_calibration.setter
	def show_calibration(self, val: bool):     self._tracker.set_calibrate_show(val)

	def start_calibration(self):
		self._tracker.set_calibrate_start(True)

	def stop_calibration(self):
		self._tracker.set_calibrate_start(False)

	def clear_calibration(self):
		self._tracker.set_calibrate_clear()
